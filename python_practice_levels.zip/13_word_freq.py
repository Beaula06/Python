t='apple banana apple';d={}
for w in t.split(): d[w]=d.get(w,0)+1
print(d)