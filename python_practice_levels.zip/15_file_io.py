open('t.txt','w').write('Hello')
print(open('t.txt').read())