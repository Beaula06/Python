arr=[1,5,3,9,7]
arr=list(set(arr));arr.sort()
print(arr[-2])