s='beaula'
print(s[::-1])