nums=[2,7,11,15];t=9;d={}
for i,n in enumerate(nums):
 if t-n in d: print([d[t-n],i]); break
 d[n]=i