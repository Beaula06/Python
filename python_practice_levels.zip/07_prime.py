n=11
print(all(n%i for i in range(2,int(n**0.5)+1)))